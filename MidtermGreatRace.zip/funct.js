document.getElementById("stopgo").addEventListener("click", startRace);
document.getElementById("winner").addEventListener("click", reset);
document.getElementById("startgarry").addEventListener("click", boom);
function boom(){
    clearInterval(timeGarry);
    document.getElementById("startgarry").src = "boomgarry.png";
}
function reset(){
    document.getElementById("winner").setAttribute("data-count-number", "0");
    document.getElementById("winner").innerHTML = "0";
    document.getElementById("stopgo").src = "stop.png";
    document.getElementById("startCoachspng").src = "spngstart.png";
    document.getElementById("startgarry").src = "startgarry.png";
    document.getElementById("startgarry").style.left = "";
    document.getElementById("startsqdsnail").style.left = "";
    document.getElementById("rock").style.left = "";
    document.getElementById("startCoachspng").style.display = "";
    document.getElementById("startCoachsqd").style.display = "";
    document.getElementById("startCoachpat").style.display = "";
}
function startRace(){
    document.getElementById("stopgo").src = "start.png";
    document.getElementById("startCoachspng").src = "agressivespng.png";
    timer = setInterval(timing, 1000);
    timeGarry = setInterval(racingGarry, 20);
    timeSqdsnail = setInterval(racingSqdsnail, 20);
}
function racingGarry(){
    spngSnail = Math.ceil((Math.random() * Math.ceil((Math.random() * 10))));
    spngSnailLoc = document.getElementById("startgarry").offsetLeft;
    sqdSnailLoc = document.getElementById("startsqdsnail").offsetLeft;
    rockLoc = document.getElementById("rock").offsetLeft;
    garry = document.getElementById("startgarry");
    if(`${spngSnailLoc}` < (window.innerWidth - 100)){
        garry.style.left = `${spngSnailLoc + spngSnail}px`;
    }
    else{
        clearInterval(timer);
        clearInterval(timeGarry);
        clearInterval(timeSqdsnail);
        document.getElementById("winner").innerHTML = "<img src='spngwinner.png'>" + "Winner!";
        document.getElementById("startCoachspng").style.display = "none";
    }
}
function racingSqdsnail(){
    sqdSnail = Math.ceil((Math.random() * Math.ceil((Math.random() * 10))));
    spngSnailLoc = document.getElementById("startgarry").offsetLeft;
    sqdSnailLoc = document.getElementById("startsqdsnail").offsetLeft;
    squidSnail = document.getElementById("startsqdsnail");
    if(`${sqdSnailLoc}` < (window.innerWidth - 100)){
        squidSnail.style.left = `${sqdSnailLoc + sqdSnail}px`;
    }
    else{
        clearInterval(timer);
        clearInterval(timeGarry);
        clearInterval(timeSqdsnail);        
        document.getElementById("winner").innerHTML = "<img src='winward.png'>" + "Winner!";
        document.getElementById("startCoachsqd").style.display = "none";    }
}
function timing(){
    num = document.getElementById("winner").getAttribute("data-count-number");
    num = Number(num);
    if ( num < 10){
        num = num + 1;
        document.getElementById("winner").innerText = num;
        document.getElementById("winner").setAttribute("data-count-number", num);
    }
    else{
        clearInterval(timer);
        clearInterval(timeGarry);
        clearInterval(timeSqdsnail);
        document.getElementById("rock").style.left = `${window.innerWidth - 100}px`;
        document.getElementById("winner").innerHTML = "<img src='winnerpatrick.png'>" + "Winner!";
        document.getElementById("startCoachpat").style.display = "none";    
    }
}